from numpy import *
import util

class PriceDataset:
    """
    X is a feature vector
    Y is the predictor variable
    """
    tr_x = None  # X (data) of training set.
    tr_y = None  # Y (label) of training set.
    val_x = None # X (data) of validation set.
    val_y = None # Y (label) of validation set.

    def __init__(self):
        ## read the csv for training (price_data_tr.csv), 
        #                   val (price_data_val.csv)
        #                   and testing set (price_data_ts.csv)
        #
        ## CAUTION: the first row is the header 
        ##          (there is an option to skip the header 
        ##            when you read csv in python csv lib.)
        
        ### TODO: YOUR CODE HERE
        tr_x = None  ### TODO: YOUR CODE HERE
        tr_y = None  ### TODO: YOUR CODE HERE
        val_x = None ### TODO: YOUR CODE HERE
        val_y = None ### TODO: YOUR CODE HERE

    def getDataset(self):
        return [self.tr_x, self.tr_y, self.val_x, self.val_y]